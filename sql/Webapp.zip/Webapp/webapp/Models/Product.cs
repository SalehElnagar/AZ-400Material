﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace az203_core.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float price { get; set; }
    }
}
